function checkCreds()
{
var firstName = document.getElementById("fname").value;
var lastName = document.getElementById("lname").Value;
var phone = document.getElementById("phone").value;

var flName = firstName+ " " +lastName;

    if (flName.length >20 || flName.length <3)

    {
        document.getElementById("loginStatus").innerHTML = "Please revise your full name";
    }

    else if (phone.length !=10)

    {
        document.getElementById("loginStatus").innerHTML = "Phone number must have 10 digits";
    }

    else
    {
        alert("You will be redirected to the BDG page");
       // location.replace("boards.htmlhttps://www.bdgacademy.com/about/our-mission/");
       window.location.href = 'https://www.bostondentalgroup.com/make-appointment/'
    }
}